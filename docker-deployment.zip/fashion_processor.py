"""
Fashion Processor - Backend Model Service
Handles all AI model inference for the multimodal fashion chatbot
"""

import logging
import torch
import torch.nn as nn
from PIL import Image
from transformers import (
    CLIPProcessor, CLIPModel, 
    WhisperProcessor, WhisperForConditionalGeneration, 
    AutoTokenizer, AutoModelForSequenceClassification
)
from sentence_transformers import SentenceTransformer
from unsloth import FastLanguageModel
import numpy as np
import faiss
import pickle
import io
import os
import tempfile
import librosa
import re

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


class SimpleFusionNetwork(nn.Module):
    """Simplified fusion model (Same structure as trained in notebook)"""
    def __init__(self, clip_model, num_classes):
        super().__init__()
        self.clip = clip_model

        # Freeze CLIP backbone
        for param in self.clip.parameters():
            param.requires_grad = False

        # Simple fusion MLP
        self.fusion_mlp = nn.Sequential(
            nn.Linear(1024, 512),
            nn.ReLU(),
            nn.Dropout(0.3),
            nn.Linear(512, 256),
            nn.ReLU(),
            nn.Dropout(0.2),
            nn.Linear(256, num_classes)
        )

    def forward(self, images, input_ids, attention_mask):
        # Get features from frozen CLIP
        with torch.no_grad():
            image_features = self.clip.get_image_features(pixel_values=images)
            text_features = self.clip.get_text_features(
                input_ids=input_ids,
                attention_mask=attention_mask
            )

            # Normalize
            image_features = image_features / image_features.norm(p=2, dim=-1, keepdim=True)
            text_features = text_features / text_features.norm(p=2, dim=-1, keepdim=True)

        # Concatenate and classify
        combined = torch.cat([image_features, text_features], dim=1)
        return self.fusion_mlp(combined)


class FashionProcessor:
    def __init__(self, model_path=None, intent_model_path=None, device=None):
        self.device = device if device else ('cuda' if torch.cuda.is_available() else 'cpu')
        logger.info(f"Using device: {self.device}")

        # Intent Configuration
        self.intent_labels = {0: "SEARCH", 1: "RECOMMEND", 2: "COMPARE", 3: "INFO", 4: "OUTFIT"}
        self.intent_model_path = intent_model_path or "./models/fine_tuned_intent_classifier"

        # Configuration
        self.clip_model_name = "openai/clip-vit-base-patch32"
        self.whisper_model_name = "openai/whisper-base"
        self.llm_model_name = "unsloth/Llama-3.2-1B-Instruct-bnb-4bit"
        self.sentence_model_name = 'sentence-transformers/all-MiniLM-L6-v2'

        self.num_classes = 46
        self.classes = [
            "shirt, blouse", "top, t-shirt, sweatshirt", "sweater", "cardigan", "jacket",
            "vest", "pants", "shorts", "skirt", "coat", "dress", "jumpsuit", "cape",
            "glasses", "hat", "headband, head covering, hair accessory", "tie", "glove",
            "watch", "belt", "leg warmer", "tights, stockings", "sock", "shoe", "bag, wallet",
            "scarf", "umbrella", "hood", "collar", "lapel", "epaulette", "sleeve", "pocket",
            "neckline", "buckle", "zipper", "applique", "bead", "bow", "flower", "fringe",
            "ribbon", "rivet", "ruffle", "sequin", "tassel"
        ]

        self.category_groups = {
            "jeans": ["jeans", "pants", "trousers", "denim"],
            "pants": ["pants", "jeans", "trousers", "denim"],
            "jacket": ["jacket", "coat", "blazer", "outerwear"],
            "coat": ["coat", "jacket", "blazer", "outerwear"],
            "dress": ["dress", "gown"],
            "shirt": ["shirt", "blouse", "top"],
            "shoes": ["shoes", "boots", "sneakers"],
            "bag": ["bag", "handbag", "purse"]
        }

        # Initialize
        self._load_models(model_path)
        self._load_database()

    def _load_models(self, model_path):
        try:
            logger.info("Loading AI Models...")

            # 1. CLIP
            logger.info("Loading CLIP model...")
            self.clip_processor = CLIPProcessor.from_pretrained(self.clip_model_name)
            self.clip_model = CLIPModel.from_pretrained(self.clip_model_name).to(self.device)

            # 2. Whisper
            logger.info("Loading Whisper model...")
            self.whisper_processor = WhisperProcessor.from_pretrained(self.whisper_model_name)
            self.whisper_model = WhisperForConditionalGeneration.from_pretrained(self.whisper_model_name).to(self.device)

            # 3. Sentence Transformer
            logger.info("Loading SentenceTransformer...")
            self.text_encoder = SentenceTransformer(self.sentence_model_name).to(self.device)

            # 4. LLM
            logger.info("Loading LLM (Llama 3.2)...")
            self.llm, self.llm_tokenizer = FastLanguageModel.from_pretrained(
                self.llm_model_name, max_seq_length=512, load_in_4bit=True
            )
            FastLanguageModel.for_inference(self.llm)

            # 5. Intent Classifier
            try:
                if os.path.exists(self.intent_model_path):
                    logger.info(f"Loading Intent Classifier from {self.intent_model_path}...")
                    self.intent_tokenizer = AutoTokenizer.from_pretrained(self.intent_model_path)
                    self.intent_model = AutoModelForSequenceClassification.from_pretrained(self.intent_model_path).to(self.device)
                    self.intent_model.eval()
                else:
                    logger.warning(f"Intent model not found at {self.intent_model_path}. Using fallback.")
                    self.intent_model = None
            except Exception as e:
                logger.error(f"Failed to load intent model: {e}")
                self.intent_model = None

            # 6. Fusion Model
            self.fusion_model = None
            if model_path and os.path.exists(model_path):
                logger.info(f"Loading Fusion Model from {model_path}...")
                try:
                    self.fusion_model = SimpleFusionNetwork(self.clip_model, len(self.classes)).to(self.device)
                    state_dict = torch.load(model_path, map_location=self.device)
                    model_dict = self.fusion_model.state_dict()
                    filtered_dict = {k: v for k, v in state_dict.items() if k in model_dict and v.shape == model_dict[k].shape}
                    model_dict.update(filtered_dict)
                    self.fusion_model.load_state_dict(model_dict)
                    self.fusion_model.eval()
                    logger.info("Fusion Model loaded successfully.")
                except Exception as e:
                    logger.error(f"Failed to load fusion weights: {e}")
                    self.fusion_model = None

            logger.info("✅ All models loaded successfully!")

        except Exception as e:
            logger.error(f"Error initializing models: {e}")
            raise e

    def _load_database(self):
        try:
            db_path = os.environ.get('FASHION_DB_PATH', './data/fashion_data.pkl')
            if os.path.exists(db_path):
                with open(db_path, 'rb') as f:
                    data = pickle.load(f)
                self.image_index = faiss.deserialize_index(data['image_index'])
                self.text_index = faiss.deserialize_index(data['text_index'])
                self.products = []
                for p in data['products']:
                    prod = {k: v for k, v in p.items() if k != 'image_bytes'}
                    if p.get('image_bytes'):
                        prod['image'] = Image.open(io.BytesIO(p['image_bytes']))
                    self.products.append(prod)
                logger.info(f"Loaded {len(self.products)} products from database.")
            else:
                logger.warning(f"Database not found at {db_path}. Search will be empty.")
                self.image_index = None
                self.text_index = None
                self.products = []
        except Exception as e:
            logger.error(f"Failed to load database: {e}")
            self.products = []

    def transcribe_audio(self, audio_bytes):
        try:
            with tempfile.NamedTemporaryFile(delete=False, suffix=".wav") as f:
                f.write(audio_bytes)
                f_name = f.name

            audio, sr = librosa.load(f_name, sr=16000)
            os.unlink(f_name)

            inputs = self.whisper_processor(audio, sampling_rate=16000, return_tensors="pt").to(self.device)
            with torch.no_grad():
                ids = self.whisper_model.generate(**inputs)
            return self.whisper_processor.batch_decode(ids, skip_special_tokens=True)[0]
        except Exception as e:
            logger.error(f"Transcription failed: {e}")
            return None

    def process_query(self, text=None, image=None, audio_bytes=None, weights={'image': 0.5, 'text': 0.35, 'audio': 0.15}, context=""):
        # 1. Input Processing
        transcribed_text = None
        if audio_bytes:
            transcribed_text = self.transcribe_audio(audio_bytes)

        combined_text = ""
        if transcribed_text: combined_text += transcribed_text + " "
        if text: combined_text += text
        combined_text = combined_text.strip()

        # 2. Embeddings
        img_emb = None
        txt_emb = None

        if image:
            inputs = self.clip_processor(images=image, return_tensors="pt").to(self.device)
            with torch.no_grad():
                img_emb = self.clip_model.get_image_features(**inputs)
                img_emb = img_emb / img_emb.norm(dim=-1, keepdim=True)
                img_emb = img_emb.cpu().numpy()

        if combined_text:
            search_text = self._rewrite_query_with_context(combined_text, context)
            txt_emb = self.text_encoder.encode([search_text], normalize_embeddings=True)

        # 3. Intent & Category Detection
        intent = self._detect_intent(combined_text)
        detected_category = None

        if image:
            if self.fusion_model:
                try:
                    txt_input = combined_text if combined_text else "fashion item"
                    inputs = self.clip_processor(text=[txt_input], images=image, return_tensors="pt", padding="max_length", truncation=True, max_length=77).to(self.device)
                    with torch.no_grad():
                        outputs = self.fusion_model(inputs.pixel_values, inputs.input_ids, inputs.attention_mask)
                        probs = torch.softmax(outputs, dim=1)
                        conf, pred_idx = torch.max(probs, 1)
                        if conf.item() > 0.4 and pred_idx.item() < len(self.classes):
                            detected_category = self.classes[pred_idx.item()]
                except Exception as e:
                    logger.error(f"Fusion prediction failed: {e}")

            if not detected_category:
                detected_category = self._classify_image_zeroshot(image)

        # 4. Search
        products = self._search_products(img_emb, txt_emb, weights, detected_category)

        # 5. Generate Response
        response = self._generate_response(combined_text, products, intent, detected_category, context)

        return {
            'intent': intent,
            'products': products,
            'response': response,
            'detected_category': detected_category,
            'transcribed_text': transcribed_text,
            'text_query': combined_text
        }

    def _rewrite_query_with_context(self, query, context):
        if not context or not query: return query

        trigger_words = ["it", "them", "that", "this", "those", "these", "match", "pair", "go with",
                        "outfit", "also", "too", "as well", "the prices", "the price"]
        context_starts = ["also", "and", "what about", "how about", "what", "can you", "give me"]
        starts_with_context = any(query.lower().startswith(word) for word in context_starts)

        should_rewrite = (len(query.split()) < 8) or \
                        any(w in query.lower() for w in trigger_words) or \
                        starts_with_context

        if not should_rewrite:
            return query

        prompt = f"""<|begin_of_text|><|start_header_id|>system<|end_header_id|>
        Your Job: Rewrite the user's latest query to be self-contained, using the conversation context.
        - Resolve references like "it", "that", "them" to the actual objects mentioned before.
        - If the query is already clear, output it exactly as is.
        - Output ONLY the rewritten text. No explanations.

        Context:
        {context}

        Latest Query: {query}
        <|eot_id|><|start_header_id|>assistant<|end_header_id|>"""

        try:
            inputs = self.llm_tokenizer(prompt, return_tensors="pt").to(self.device)
            out = self.llm.generate(**inputs, max_new_tokens=50)
            rewritten = self.llm_tokenizer.decode(out[0], skip_special_tokens=True).split("assistant")[-1].strip()
            if not rewritten or len(rewritten) < 2: return query
            logger.info(f"Rewrote query: '{query}' -> '{rewritten}'")
            return rewritten
        except Exception as e:
            logger.error(f"Query rewriting failed: {e}")
            return query

    def _detect_intent(self, text):
        if not text: return "SEARCH"

        if hasattr(self, 'intent_model') and self.intent_model:
            try:
                inputs = self.intent_tokenizer(text, return_tensors="pt", truncation=True, padding=True).to(self.device)
                with torch.no_grad():
                    logits = self.intent_model(**inputs).logits
                    idx = torch.argmax(logits, dim=1).item()
                    return self.intent_labels.get(idx, "SEARCH")
            except Exception as e:
                logger.error(f"Intent inference failed: {e}")

        # Fallback
        text = text.lower()
        if any(w in text for w in ["outfit", "style", "pair", "suggest"]): return "RECOMMEND"
        if any(w in text for w in ["compare", "vs", "better"]): return "COMPARE"
        if any(w in text for w in ["recommend", "suggest"]): return "RECOMMEND"
        if any(w in text for w in ["detail", "material", "size", "price"]): return "INFO"
        if any(w in text for w in ["similar", "like this", "more"]): return "OUTFIT"
        return "SEARCH"

    def _classify_image_zeroshot(self, image):
        short_cats = [c.split(',')[0] for c in self.classes]
        inputs = self.clip_processor(text=short_cats, images=image, return_tensors="pt", padding=True).to(self.device)
        with torch.no_grad():
            outputs = self.clip_model(**inputs)
            probs = outputs.logits_per_image.softmax(dim=1)
            idx = probs.argmax().item()
        return short_cats[idx]

    def _search_products(self, img_emb, txt_emb, weights, category_filter=None):
        if not self.products: return []

        results = {}

        if img_emb is not None and self.image_index:
            scores, ids = self.image_index.search(img_emb, 20)
            for s, i in zip(scores[0], ids[0]):
                if 0 <= i < len(self.products):
                    score = float(s) * weights.get('image', 0.5)
                    results[i] = results.get(i, 0) + score

        if txt_emb is not None and self.text_index:
            scores, ids = self.text_index.search(txt_emb, 20)
            for s, i in zip(scores[0], ids[0]):
                if 0 <= i < len(self.products):
                    score = float(s) * weights.get('text', 0.35)
                    results[i] = results.get(i, 0) + score

        final_list = []
        for pid, score in sorted(results.items(), key=lambda x: x[1], reverse=True):
            p = self.products[pid]

            if category_filter:
                p_cat = p.get('category', '').lower()
                filter_cat = category_filter.lower()

                filter_synonyms = [filter_cat]
                for key, synonyms in self.category_groups.items():
                    if filter_cat in [s.lower() for s in synonyms]:
                        filter_synonyms = [s.lower() for s in synonyms]
                        break

                match_found = False
                for synonym in filter_synonyms:
                    if synonym in p_cat or p_cat in synonym:
                        match_found = True
                        break

                if not match_found:
                    continue

            p['similarity'] = score * 100
            final_list.append(p)
            if len(final_list) >= 5: break

        return final_list

    def _generate_response(self, query, products, intent, category, context):
        if not products:
            return "I couldn't find any matching items. Could you try a different search or upload a clearer image?"

        prod_lines = []
        for p in products:
            parts = [f"{p['name']} ({p.get('category', 'item')})"]
            if p.get('brand') and p['brand'] != 'Generic':
                parts.append(f"by {p['brand']}")
            if p.get('price'):
                parts.append(f"${p['price']}")
            if p.get('color'):
                parts.append(f"color: {p['color']}")
            if p.get('material'):
                parts.append(f"material: {p['material']}")
            prod_lines.append("- " + " | ".join(parts))

        prod_desc = "\n".join(prod_lines)

        prompt = f"""<|begin_of_text|><|start_header_id|>system<|end_header_id|>
        You are a friendly fashion stylist. The customer searched and YOU found the items below.
        
        RULES:
        - Sound natural and conversational
        - Keep it SHORT - 1-2 sentences max
        - Don't mention percentages or scores
        - Only discuss style, color, brand, price
        - The user will see images, don't list every item
        <|eot_id|><|start_header_id|>user<|end_header_id|>

        User asked: "{query}"

        Available Items:
        {prod_desc}
        <|eot_id|><|start_header_id|>assistant<|end_header_id|>
        """

        try:
            inputs = self.llm_tokenizer(prompt, return_tensors="pt").to(self.device)
            out = self.llm.generate(**inputs, max_new_tokens=150)
            response = self.llm_tokenizer.decode(out[0], skip_special_tokens=True).split("assistant")[-1].strip()
            response = re.sub(r'\s*\([^)]*(?:response|short|concise|enthusias|tone|friendly|casual)[^)]*\)', '', response, flags=re.IGNORECASE)
            return response.strip()
        except Exception as e:
            return f"Here are some {category if category else 'fashion'} items I found for you: " + ", ".join([p['name'] for p in products])
