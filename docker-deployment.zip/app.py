"""
Fashion Assistant - Streamlit UI Frontend
Multimodal chatbot interface supporting text, image, and voice inputs
"""

import streamlit as st
import torch
import numpy as np
from PIL import Image
import os
from audio_recorder_streamlit import audio_recorder
from fashion_processor import FashionProcessor

# Page Config
st.set_page_config(
    page_title="Fashion Assistant",
    layout="wide",
    page_icon="👗"
)

# Initialize session state for processor
if "processor" not in st.session_state:
    st.session_state.processor = None

@st.cache_resource
def get_processor():
    """Load the Fashion Processor with all AI models"""
    model_path = os.environ.get('FUSION_MODEL_PATH', './models/fashion_fusion_model.pth')
    intent_path = os.environ.get('INTENT_MODEL_PATH', './models/fine_tuned_intent_classifier')
    
    return FashionProcessor(
        model_path=model_path if os.path.exists(model_path) else None,
        intent_model_path=intent_path if os.path.exists(intent_path) else None
    )

# Load processor with spinner
with st.spinner("🔄 Loading AI Models... This may take a moment."):
    if st.session_state.processor is None:
        st.session_state.processor = get_processor()

# Session State Initialization
if "messages" not in st.session_state: st.session_state.messages = []
if "current_image" not in st.session_state: st.session_state.current_image = None
if "current_voice" not in st.session_state: st.session_state.current_voice = None
if "current_text" not in st.session_state: st.session_state.current_text = ""
if "file_uploader_key" not in st.session_state: st.session_state.file_uploader_key = 0
if "audio_processed" not in st.session_state: st.session_state.audio_processed = False
if "image_processed" not in st.session_state: st.session_state.image_processed = False
if "recorded_audio_processed" not in st.session_state: st.session_state.recorded_audio_processed = False

# UI Header
st.title("👗 Fashion Assistant")
st.caption("🛍️ Multimodal Search: Text, Image & Voice")

# SIDEBAR
with st.sidebar:
    st.header("🎯 How to Search")
    st.info("""
    **Use any input method:**
    - 📝 **Text** - Describe what you want
    - 📷 **Image** - Upload a photo (auto-search)
    - 🎤 **Voice** - Record your request (auto-search)

    **Or combine them** and click "Search"!
    """)

    st.divider()

    # TEXT INPUT
    st.subheader("📝 Text Query")
    text_input = st.text_area(
        "Describe what you want",
        value=st.session_state.current_text,
        placeholder="e.g., blue summer dress, a casual jacket...",
        height=80,
        key="text_area_" + str(st.session_state.file_uploader_key),
        help="Type any fashion item, style, or occasion"
    )
    if text_input:
        st.session_state.current_text = text_input.strip()

    st.divider()

    # IMAGE INPUT
    st.subheader("📷 Image Search")
    st.caption("Upload a photo to find similar items")
    uploaded_image = st.file_uploader(
        "Upload an image",
        type=["jpg", "jpeg", "png"],
        key="img_" + str(st.session_state.file_uploader_key)
    )

    if uploaded_image and not st.session_state.image_processed:
        img = Image.open(uploaded_image).convert("RGB")
        st.session_state.current_image = img
        st.image(img, caption="✅ Image loaded", use_container_width=True)
        st.session_state.image_processed = True
    elif st.session_state.current_image:
        st.image(st.session_state.current_image, caption="✅ Current image", use_container_width=True)

    st.divider()

    # VOICE INPUT
    st.subheader("🎤 Voice Input")
    st.caption("🔴 Record your voice:")
    audio_bytes = audio_recorder(
        text="Click to record",
        recording_color="#e74c3c",
        neutral_color="#6c757d",
        icon_size="2x",
        pause_threshold=2.0,
        key="audio_recorder_" + str(st.session_state.file_uploader_key)
    )

    if audio_bytes and not st.session_state.recorded_audio_processed:
        st.audio(audio_bytes, format="audio/wav")
        with st.spinner("🎙️ Transcribing..."):
            transcribed = st.session_state.processor.transcribe_audio(audio_bytes)
            if transcribed:
                st.session_state.current_voice = transcribed.strip()
                st.session_state.recorded_audio_processed = True
                st.success("✅ " + transcribed)
            else:
                st.error("❌ Could not transcribe. Try again.")

    # Upload Audio File Option
    uploaded_audio = st.file_uploader(
        "Or upload an audio file",
        type=["wav", "mp3", "m4a", "ogg", "webm"],
        key="audio_upload_" + str(st.session_state.file_uploader_key),
        help="Upload a pre-recorded voice note"
    )

    if uploaded_audio and not st.session_state.audio_processed:
        st.audio(uploaded_audio)
        with st.spinner("🎙️ Transcribing uploaded file..."):
            audio_data = uploaded_audio.read()
            transcribed = st.session_state.processor.transcribe_audio(audio_data)
            if transcribed:
                st.session_state.current_voice = transcribed.strip()
                st.session_state.audio_processed = True
                st.success("✅ Uploaded audio transcribed: " + transcribed)
            else:
                st.error("❌ Could not transcribe uploaded file.")

    if st.session_state.current_voice:
        st.success("🎤 " + st.session_state.current_voice)

    # ACTIVE INPUTS DISPLAY
    active_inputs = []
    if st.session_state.current_text:
        active_inputs.append("📝 Text")
    if st.session_state.current_image:
        active_inputs.append("📷 Image")
    if st.session_state.current_voice:
        active_inputs.append("🎤 Voice")

    if active_inputs:
        st.info("**Active inputs:** " + " + ".join(active_inputs))
    else:
        st.warning("💡 Add text, image, or voice to search")

    # BUTTONS
    col1, col2 = st.columns(2)
    with col1:
        search_button = st.button("🔍 Search", type="primary", use_container_width=True)
    with col2:
        clear_button = st.button("🗑️ Clear All", use_container_width=True)

    if clear_button:
        st.session_state.messages = []
        st.session_state.current_image = None
        st.session_state.current_voice = None
        st.session_state.current_text = ""
        st.session_state.image_processed = False
        st.session_state.recorded_audio_processed = False
        st.session_state.audio_processed = False
        st.session_state.file_uploader_key += 1
        st.rerun()

# CHAT HISTORY DISPLAY
for msg in st.session_state.messages:
    with st.chat_message(msg["role"]):
        st.write(msg["text"])
        if msg.get("products"):
            cols = st.columns(5)
            for i, p in enumerate(msg["products"][:5]):
                with cols[i]:
                    if p.get("image"):
                        st.image(p["image"], width=120)
                    product_name = p["name"][:25] + "..." if len(p["name"]) > 25 else p["name"]
                    st.markdown(f"**{product_name}**")
                    if p.get("category"):
                        st.caption(f"🏷️ {p['category']}")

# SEARCH LOGIC
if search_button:
    text_q = st.session_state.current_text
    img_q = st.session_state.current_image
    voice_q = st.session_state.current_voice

    if not text_q and not img_q and not voice_q:
        st.warning("⚠️ Please add at least one input!")
    else:
        # Build context from recent messages
        context = ""
        for m in st.session_state.messages[-4:]:
            context += f"{m['role']}: {m['text']}\n"

        # Process Query
        with st.spinner("🤖 Analyzing & Searching..."):
            result = st.session_state.processor.process_query(
                text=text_q,
                image=img_q,
                audio_bytes=None,
                context=context
            )

            # Re-run with voice if text was empty
            if voice_q and not text_q:
                result = st.session_state.processor.process_query(
                    text=voice_q,
                    image=img_q,
                    context=context
                )

        # Update Chat
        user_msg_parts = []
        if voice_q: user_msg_parts.append(f"🎤 {voice_q}")
        if text_q: user_msg_parts.append(f"📝 {text_q}")
        if img_q: user_msg_parts.append("📷 [image]")

        st.session_state.messages.append({
            "role": "user",
            "text": " | ".join(user_msg_parts)
        })

        st.session_state.messages.append({
            "role": "assistant",
            "text": result['response'],
            "products": result['products']
        })

        # Reset inputs
        st.session_state.current_image = None
        st.session_state.current_voice = None
        st.session_state.current_text = ""
        st.session_state.image_processed = False
        st.session_state.recorded_audio_processed = False
        st.session_state.audio_processed = False
        st.session_state.file_uploader_key += 1
        st.rerun()

# QUICK TEXT INPUT
st.divider()
prompt = st.chat_input("💬 Quick text search")
if prompt:
    img_q = st.session_state.current_image

    with st.spinner("🤖 Thinking..."):
        result = st.session_state.processor.process_query(text=prompt, image=img_q)

    st.session_state.messages.append({
        "role": "user",
        "text": prompt + (" 📷" if img_q else "")
    })
    st.session_state.messages.append({
        "role": "assistant",
        "text": result['response'],
        "products": result['products']
    })

    if img_q:
        st.session_state.current_image = None
        st.session_state.image_processed = False
        st.session_state.file_uploader_key += 1
    st.rerun()
